package com.apptware.interview.spring.beans;

public interface OnDemand {

  SomeEnum getSomeEnum();

  String getSomeString();
}
