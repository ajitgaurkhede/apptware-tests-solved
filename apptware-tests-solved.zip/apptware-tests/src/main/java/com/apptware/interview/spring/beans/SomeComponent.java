package com.apptware.interview.spring.beans;

import org.springframework.stereotype.Component;

@Component
class SomeComponent {

  String processSomeString(String string) {
    return string;
  }
}
