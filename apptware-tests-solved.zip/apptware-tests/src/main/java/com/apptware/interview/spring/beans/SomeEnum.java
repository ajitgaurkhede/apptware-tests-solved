package com.apptware.interview.spring.beans;

public enum SomeEnum {
  SOME_ENUM_A,
  SOME_ENUM_B;
}
